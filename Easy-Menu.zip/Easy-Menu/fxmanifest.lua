client_script "@EC_AC/shared.lua"

--[[
	███████╗ █████╗ ███████╗██╗   ██╗██████╗
	██╔════╝██╔══██╗██╔════╝╚██╗ ██╔╝╚════██╗
	█████╗  ███████║███████╗ ╚████╔╝   ▄███╔╝
	██╔══╝  ██╔══██║╚════██║  ╚██╔╝    ▀▀══╝
	███████╗██║  ██║███████║   ██║     ██╗
	╚══════╝╚═╝  ╚═╝╚══════╝   ╚═╝     ╚═╝
	=========================================

	Made By : Easy?#1111
    Discord : https://easy.community/request/redirect?l=discord

	♥ شكرا لثقتك بنا ♥
]]
fx_version 'cerulean'
game 'gta5'

server_scripts{
    "@mysql-async/lib/MySQL.lua",
	'@vrp/lib/utils.lua',
	'الاعدادات/الرئيسية.lua',
	'الاعدادات/الادارة.lua',
	'الاعدادات/الشرطة.lua',
	'الاعدادات/العصابات.lua',
	'الاعدادات/المواطنين.lua',
	'الاعدادات/الفعاليات.lua',
	'Files/server.lua'
}

client_scripts{
    'Files/client.lua'
}

ui_page_preload 'yes'
ui_page 'Files/html/menu.html'

files {
    'Files/html/*.*',
}
--[[
	███████╗ █████╗ ███████╗██╗   ██╗██████╗
	██╔════╝██╔══██╗██╔════╝╚██╗ ██╔╝╚════██╗
	█████╗  ███████║███████╗ ╚████╔╝   ▄███╔╝
	██╔══╝  ██╔══██║╚════██║  ╚██╔╝    ▀▀══╝
	███████╗██║  ██║███████║   ██║     ██╗
	╚══════╝╚═╝  ╚═╝╚══════╝   ╚═╝     ╚═╝
	=========================================

	Made By : Easy?#1111
    Discord : https://easy.community/request/redirect?l=discord

	♥ شكرا لثقتك بنا ♥
]]