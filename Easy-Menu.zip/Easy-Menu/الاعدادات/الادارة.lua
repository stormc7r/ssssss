--[[
	███████╗ █████╗ ███████╗██╗   ██╗██████╗ 
	██╔════╝██╔══██╗██╔════╝╚██╗ ██╔╝╚════██╗
	█████╗  ███████║███████╗ ╚████╔╝   ▄███╔╝
	██╔══╝  ██╔══██║╚════██║  ╚██╔╝    ▀▀══╝ 
	███████╗██║  ██║███████║   ██║     ██╗   
	╚══════╝╚═╝  ╚═╝╚══════╝   ╚═╝     ╚═╝
	=========================================
	
	Made By : Easy?#1111
    Discord : https://easy.community/request/redirect?l=discord
	
	♥ شكرا لثقتك بنا ♥
]]
Menu.Admin = {
	
	RefilFD = { -- الاكل و الشرب
		Timer = 5, -- المدة بالدقائق  للانتي سبام
		Heal = true, -- لو ما تبيه يعبي الدم طفي الخيار
	},
	
	Jail = { -- سجن الادارة
		Max = 60, -- المدة الاقصى لسجن الادرة بالدقائق
		Bypass = '', -- هنا ضيف برمشن يقدر يتخطى المدة المضافة فوق [NEW]
		
		Chat = true, -- طفي الخيار لو ما تبي يظهر في الشات وقت لاعب ينسجن من قبل اداري
		
		In = {1756.134,2487.902,48.086}, -- احداثيات سجن الادرة
		Out = {1847.135,2585.978,47.058}, -- خروج من سجن الادرة
	},
	
	AntiSpectate = '', -- برمشن الاشخاص الي ما تبيهم ينعمل لهم سبيكتيك
	
    TopPermissions = { -- الادارة المحمية
        -- اكتب ايديات الادارة الي ما تبيها تنسحب, تتبند, تنطرد
        
		Bypass = '',
		
		Disable = {
            Ban = true, -- منع الباند
            Kick = true, -- منع الحظر
            TpTo = true, -- منع الانتقال
            TpMe = true, -- منع السحب
            Jail = true -- منع السجن
        },
        IDs = {
            [-2] = true,
            [-1] = true,
            [0] = true,
            [1] = true,
            [2] = true,
            [3] = true,
            [4] = true,
        }
    },
	
	HiddenGroups = { -- الرتبة المخفية
		--[[
				هنا يمديك تضيف الرتب الي ما تبيها تطلع في المنيو
			:رح يتم اخفائها ف يالاماكن التالية
			خيار الاستعلام عن الرتب
			اللوقات
		]]
		{group = "h+e-l**p-e+r" --[[ الرتبة التبي تخفيها ]], show = "HELPER" --[[ الرتبة اليتم اظهارها ]] },
		{group = "f*i*rs-t", show = "FIRST"},
		{group = "TR/I***+9+A-L", show = "TRIAL"},
		{group = "S+U-P+E+++R--V+++I-S+OR", show = "SUPERVISOR"},
		{group = "MODER++A/T*O***R+", show = "MODERATOR"},
		{group = "m+a-s*t-e++/r", show = "MASTER"},
	},
	
	TargetVehicles = { -- المركبات التنزل للاعب لو الادمن انزل مركبة لاقرب لاعب
		'panto', -- لو ضفت اكثر من وحدة المنيو رح تنزل بشكل عشوائي
		'blista',
		-- '',
		-- '',
	},
	
	
	AntiVehicle = { -- المركبات الي ما تبي الادمن ينزلها من المنيو لنفسه
		Bypass = "admin.manager", -- برمشن يتخطيهم
		
		HASH = {
			'hydra',
			-- 'rhino',
			-- 'lazer'
		}
	},
	
	SkinChanger = { -- السكنات الي تجي للاعب لو الادمن غير لبسه
		-- المنيو رح تختار سكن من السكنات بشكل عشوائي
		'mp_m_freemode_01', 
		'mp_f_freemode_01',
	},
	
	Permissions = { -- البرمشنات
		-- يمديك تضيف برمشن او رتبة
	
		--[[
			! تنبيه !
			الاداري لازم يكون معاه برمشن الخيار الاونلاين عشان يقدر يستخدم خيار الاوفلاين
		]]
		Crash = "player.kick", -- كراش لاعب
		Clothes = "admin.tickets", -- تغيير اللبس
		Spectate = "admin.tickets", -- مراقبة لاعب
		OfflineBan = 'player.ban', -- بان اوفلاين
		Heartbeat = "admin.tickets", -- heartbeat امر 
		AUnjail = "admin.ajail", -- فك سجن الادارة
		SelfRevive = "admin.tickets", -- انعاش نفسك
		ATargetJail = "admin.ajail", -- سجن الادارة
		AllRevive = "admin.reviveall", -- انعاش الكل
		NearRevive = "admin.nrevive", -- انعاش المحيط
		FoodDrink = "admin.tickets", -- الاكل و الشرب
		TargetRevive = "admin.revive", -- انعاش عن بعد
		RequestTpMe = "player.tptome", -- طلب سحب لاعب
		AdminTpAll = "admin.manager", -- سحب جميع الادارة
		AdminMessage = "admin.manager", -- رسالة الى الادارة
		RequestTpTo = "player.tpto", -- طلب الانتقال الى لاعب
		OfflineAddGroup = "player.group.add", -- اعطاء رتبة اوفلاين 
		AdminCheckRole = "player.group.remove", -- استعلام عن الرتب
		OfflineUnJail = "admin.ajail", -- فك سجن الادارة
		OfflineJail = "admin.ajail", -- سجن اوفلاين
		ResrcStop = "admin.tickets", -- ايقاف سكربت | لو عندك حماية لا تشغله
		ResrcStart = "admin.tickets", -- تشغيل سكربت | لو عندك حماية لا تشغله
		TargetSpawnVehicle = "admin.spawnveh", -- انزال المركبة لاقرب لاعب
		ResrcRestart = "admin.tickets", -- اعادة تشغيل سكربت | لو عندك حماية لا تشغله
	},

	Logs = { -- اللوقات
		Ban = "", -- لوق البان
		Kick = "", -- لوق الطرد
		TpMe = "", -- لوق السحب
		Unban = "", -- لوق فك بان
		Crash = "", -- لوق الكراش
		TpTo = "", -- لوق الانتقال
		Noclip = "https://discord.com/api/webhooks/1129935008967172196/2zU4H9RhLJsQYbQKvg5hn0A09oihP2yR48R-_XXfdlRIGGQTJDBK39Xlk12PQoVtBLYf", -- لوق الطيران
		AUnjail = "", -- لوق فك السجن
		Clothes = "", -- لوق تغيير اللبس
		Spectate = "", -- لوق المراقبة
		Heartbeat = "", -- لوق Heartbeat
		RequestTpMe = "", -- لوق طلب سحب
		AllRevive = "", -- لوق انعاش الكل
		Coords = "", -- لوق نسخ الاحداثيات
		Coords = "", -- لوق نسخ الاحداثيات
		SelfRevive = "", -- لوق انعاش النفس
		ResrcStart = "", -- لوق تشغيل سكربت
		ResrcStop = "",  -- لوق ايقاف سكربت
		OfflineBan = "", -- لوق بان اوفلاين
		FoodDrink = "", -- لوق الاكل و الشرب
		NearRevive = "", -- لوق انعاش المحيط
		ATargetJail = "", -- لوق سجن الادارة
		RequestTpTo = "", -- لوق طلب الانتقال
		AdminAddGroup = "", -- لوق اعطاء رتبة
		TargetRevive = "", -- لوق انعاش عن بعد
		AdminRemoveGroup = "", -- لوق سحب رتبة
		AdminTpAll = "",  -- لوق سحب جميع الادارة
		AdminCheckRole = "", -- لوق استعلام عن رتب
		SelfSpawnVehicle = "", -- انزال مركبة لنفسك
		TpWaypoint = "", -- لوق الانتقال اللى النقطة
		AdminMessage = "", -- لوق راسالة الى الادارة
		TpCoords = "", -- لوق الانتقال الى الاحداثيات
		ResrcRestart = "", -- لوق اعادة تشغيل السكربت
		TargetSpawnVehicle = "", -- لوق انزال مركبة لاقرب لاعب
	},

	-- >>>>>>>>>>>>>>>>>>>>>>>>>>>> للمبرمجين فقط <<<<<<<<<<<<<<<<<<<<<<<<<<<<

	-- >>>>>>>>>>>>>>>>>>> لا تعدل اذا كنت مو عارف وش قاعد تسوي <<<<<<<<<<<<<<<<<<<

	OuterLabels = { "imgsrc:Q05959p.png", "imgsrc:XflM23L.png", "imgsrc:u2Acrwd.png", "imgsrc:UN6CVt6.png", "imgsrc:c6yF26R.png", "imgsrc:QQH5Wg3.png", "imgsrc:EVOyy9C.png", "imgsrc:e06LDwf.png", "imgsrc:9Xjr4kk.png", "imgsrc:utcx7lT.png", "imgsrc:EUijGeR.png", "imgsrc:QIgJUD6.png", "imgsrc:BDKNDnc.png", "imgsrc:nMOebpU.png", "imgsrc:ZL6rYRM.png" },
	OuterCommands = { Menu.Close, "eSelfSpawnVehicle", "eAdminAddGroup", "eBan", "eSpectate", "eUnban", "eKick", "eNoclip", "eFoodDrink", "eAllRevive", "eChangeClothes", "eATargetJail", "eAUnjail", "AdminAddons-Menu", "eNearRevive" },

	InnerLabels = { "imgsrc:33LzXrO.png", "imgsrc:Oe9auwE.png", "imgsrc:SWGvKCY.png", "imgsrc:h0BW2KT.png" }, 
	InnerCommands = { "eTpTo", "eTargetRevive", "eTpMe", "eTpWaypoint" },

	SubMenus = {
		["AdminAddons-Menu"] = { -- لازم تضيف -Menu لكل وحدة تبي تضيفها
			labels = { "imgsrc:LprJG0G.png", "imgsrc:dgS7L8E.png", "imgsrc:c1dUftq.png", "imgsrc:x0jGOLm.png", "imgsrc:nr1ZhPn.png", "imgsrc:29YteaU.png"}, 
			commands = { "eSelfSpawnVehicle", "eAdminCheckRole", "eRequestTpMe", "AdminManager-Menu", "Dev-Menu", "eRequestTpTo" }
		},
		["Dev-Menu"] = {
			labels = { "imgsrc:BHcqxB4.png", "imgsrc:mFJ20Zb.png", "imgsrc:seO31G2.png", "imgsrc:5FT536G.png" }, 
			commands = { "eHeartbeat", "eTpCoords", "Coords-Menu", "Script-Menu" }
		},
		["AdminManager-Menu"] = {
			labels = { "imgsrc:CT42L0u.png", "imgsrc:er9ZzOr.png" }, 
			commands = { "eAdminMessage", "eAdminTpAll" }
		},
		["Coords-Menu"] = {
			labels = { "imgsrc:136PQA2.png", "imgsrc:DXLfvJJ.png", "imgsrc:jV8wg1g.png" }, 
			commands = { "eCoords1", "eCoords2", "eCoords3" }
		},
		["Script-Menu"] = {
			labels = { "imgsrc:GugMC4C.png", "imgsrc:Ibwwwff.png", "imgsrc:GqrcRM2.png" }, 
			commands = { "eResrcStart", "eResrcStop", "eResrcRestart"}
		}
	}
}

--[[
	███████╗ █████╗ ███████╗██╗   ██╗██████╗ 
	██╔════╝██╔══██╗██╔════╝╚██╗ ██╔╝╚════██╗
	█████╗  ███████║███████╗ ╚████╔╝   ▄███╔╝
	██╔══╝  ██╔══██║╚════██║  ╚██╔╝    ▀▀══╝ 
	███████╗██║  ██║███████║   ██║     ██╗   
	╚══════╝╚═╝  ╚═╝╚══════╝   ╚═╝     ╚═╝
	=========================================
	
	Made By : Easy?#1111
    Discord : https://easy.community/request/redirect?l=discord
	
	♥ شكرا لثقتك بنا ♥
]]