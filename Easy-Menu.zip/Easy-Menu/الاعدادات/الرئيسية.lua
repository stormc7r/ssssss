--[[
	███████╗ █████╗ ███████╗██╗   ██╗██████╗ 
	██╔════╝██╔══██╗██╔════╝╚██╗ ██╔╝╚════██╗
	█████╗  ███████║███████╗ ╚████╔╝   ▄███╔╝
	██╔══╝  ██╔══██║╚════██║  ╚██╔╝    ▀▀══╝ 
	███████╗██║  ██║███████║   ██║     ██╗   
	╚══════╝╚═╝  ╚═╝╚══════╝   ╚═╝     ╚═╝
	=========================================
	
	Made By : Easy?#1111
    Discord : https://easy.community/request/redirect?l=discord
	
	♥ شكرا لثقتك بنا ♥
]]
Menu = Easy or Peasy or Lemon or Squeezy or {
	
	License = 'u4LQXWReY0H62HuwskNY', -- الرخصة
	
	Info = { -- معلومات السيرفر
		discord = "https://discord.gg/5TJWR764fs", -- رابط الدسكورد
		logo = "https://easy.community/LogoV2", -- رابط شعار السيرفر
		name = "IRAQ DREAM" -- اسم السيرفر
	},
	
	-- حجم المنيو الافتراضي
	Size = 'medium', -- small, medium, big
	
	Keys = { -- ازرار المنيو
		Main = "F7", -- القائمة الرئيسية
		Admin = "F1", -- قائمة الادارة
		Police = "Z", -- قائمة الشرطة
		Citizen = "U", -- قائمة المواطنين
		Event = "F9", -- قائمة الفعاليات
		Gang = "G" -- قائمة العصابات
	},

	Move = true, -- تفعيل مييزة القدرة على المشي هو واللاعب فاتح المنيو
	
	Animate = true, -- تفعيل تحريكات خفيفة تعطي شكل حلو للمنيو
	
	Disable = { -- هنا حدد لو تبي المنيو تفتح مثلا وقت اللاعب يكون مكلبش, او ميت
		inComa = false, -- فعل الخيار لو ما تبيه يقدر يفتح القوائم هو وميت (اللاعب رح يقدر يفتح قائمة الادمن فقط)
		Cuff = true -- فعل الخيار لو ما تبي اللاعب يفتح القوائم هو ومكلبش (رح يشمل جميع اللاعبين بدون استثناء)
	},
	
	Close = "closemenu", -- closeitz, closed7z هنا يمديك تضيف الكوماند حق اغلاق المنيو  مثلا 
	
	-- >>>>>>>>>>>>>>>>>>>>>>>>>>>> للمبرمجين فقط <<<<<<<<<<<<<<<<<<<<<<<<<<<<

	-- >>>>>>>>>>>>>>>>>>> لا تعدل اذا كنت مو عارف وش قاعد تسوي <<<<<<<<<<<<<<<<<<<
	OuterLabels = { "imgsrc:b9YvapJ.png", "imgsrc:TKtkiyR.png", "imgsrc:CwULpfk.png", "imgsrc:tMy5kKV.png", "imgsrc:Bf4ZdY4.png", "imgsrc:Nd7xySl.png" },
	OuterCommands = { "Admin", "Police", "Citizen", "Bookmarks", "Event", "Gang" },
}

function MenuNotification(player, data) -- الاشعار ما يحتاج تغيره المنيو فيها اشعار منفسها
	local text = data.text
	local type = data.type -- error, success, warning
	local timeout = 5000

	TriggerClientEvent("pNotify:SendNotification",player,{
		text = text, 
		type = type, 
		timeout = timeout,
		layout = "centerLeft"
	})
end

function MessageNotification(player,data)
	local text = data.text
	local type = data.type
	local timeout = data.timeout
	
	TriggerClientEvent("pNotify:SendNotification", player, {text = text, type = type, timeout = timeout, layout = "centerLeft"})
end
--[[
	███████╗ █████╗ ███████╗██╗   ██╗██████╗ 
	██╔════╝██╔══██╗██╔════╝╚██╗ ██╔╝╚════██╗
	█████╗  ███████║███████╗ ╚████╔╝   ▄███╔╝
	██╔══╝  ██╔══██║╚════██║  ╚██╔╝    ▀▀══╝ 
	███████╗██║  ██║███████║   ██║     ██╗   
	╚══════╝╚═╝  ╚═╝╚══════╝   ╚═╝     ╚═╝
	=========================================
	
	Made By : Easy?#1111
    Discord : https://easy.community/request/redirect?l=discord
	
	♥ شكرا لثقتك بنا ♥
]]