--[[
	███████╗ █████╗ ███████╗██╗   ██╗██████╗ 
	██╔════╝██╔══██╗██╔════╝╚██╗ ██╔╝╚════██╗
	█████╗  ███████║███████╗ ╚████╔╝   ▄███╔╝
	██╔══╝  ██╔══██║╚════██║  ╚██╔╝    ▀▀══╝ 
	███████╗██║  ██║███████║   ██║     ██╗   
	╚══════╝╚═╝  ╚═╝╚══════╝   ╚═╝     ╚═╝
	=========================================
	
	Made By : Easy?#1111
    Discord : https://easy.community/request/redirect?l=discord
	
	♥ شكرا لثقتك بنا ♥
]]
Menu.Police = {

	-- Key = "~",  -- زر فتح القائمة شغله لو تبي زر مخصص
	
	Jail = { -- سجن الشرطة
		Max = 60, -- المدة الاقصى للسجن
		
		In = {1756.134,2487.902,48.086}, -- دخول السجن
		Out = {1847.135,2585.978,47.058}, -- خروج السجن
	},
	
	AntiLoot = {"dontloot", "easy.dontloot"}, -- اللاعبين ما رح يقدرو يلوتو الاشخاص العندهم برمشن من هاذي البرمشنات , يمديك تضيف برمشنات بعدد لا نهائي
	
	Discounts = { -- الخصومات على السجن و المخالفات
		{"batman.vip" --[[ البرمشن او الرتبة ]], 30 --[[ الخصم بالمية على المخالفات ]], 20  --[[ الخصم بالمية على السجن ]]},
		{"فورتنايت", 60, 25},
		-- يمديك تضيف بشكل لا نهائي
	},
	
	ShieldTimer = 0.25, -- كل كم ثانية يقدر العسكري يعبي الدرع؟ [NEW]
	
	Loadout = { -- عتاد الشرطة
		Timer = 10, -- المدة بالدقائق للانتي سبام
		
		Shield = true, -- هل تبي يجي درع للاعب وقت يستلم العتاد؟
		
		Weapons = { -- الاسلحة
			["WEAPON_FLAREGUN"] = {ammo=999},
			["WEAPON_PISTOL"] = {ammo=999},
			["WEAPON_ASSAULTRIFLE"] = {ammo=999},
			["WEAPON_HEAVYSHOTGUN"] = {ammo=999},
			["WEAPON_STUNGUN"] = {ammo=999},
			["WEAPON_NIGHTSTICK"] = {ammo=999},
		}
	},
	
	Ranks = { -- رتب الشرطة من اوطى رتبة الى اعلى, يمديك تضيف عدد لا نهائي
		"عاطل", 
		"عسكري متدرب",
		"جندي",
		"جندي اول",
		"عريف",
		"وكيل رقيب",
		"رقيب",
		"رقيب اول",
		"رئيس الرقباء",
		"ملازم",
		"ملازم اول",
		"نقيب",
		"رائد",
		"مقدم",
		"عقيد",
		"عميد",
		"لواء",
		"فريق",
		"فريق اول",
		"مستشار وزير الداخلية",
		"نائب وزير الداخلية",
		"وزير الداخلية"
	},
	
	eRanks = { -- رتب اللصحة  من اوطى رتبة الى اعلى, يمديك تضيف عدد لا نهائي
		"عاطل",
		"مسعف تحت التدريب",
		"مسعف",
		"ممرض",
		"دكتور",
		"طبيب",
		"اخصائي",
		"استشاري",
		"بروفيسور",
		"نائب مدير المستشفى",
		"مدير المستشفى",
		"نائب مسؤول المسعفين",
		"مسؤول المسعفين",
		"نائب وزير الصحة",
		"وزير الصحة"
	},
	
	EMS = { -- المسعفين
		ReviveTry = 3000, -- المبلغ الي ينسحب من اللاعب عند انعاشه
		ReviveAdd = 3500, -- اللاعب الي يستلمه المسعف عند انعاش اللاعب
		
		RefilTry = 2000, -- المبلغ الينسحب من اللاعب عند تعبئة الدم
		RefilAdd = 3000, -- المبلغ اليستلمه المسعف عند تعبئة دم للاعب
	},
	
	Uniforms = { -- البريها
		-- هنا يمديك تضيف اكثر من بريهة لكل قطاع
		["eUniform"] --[[ هنا ضيف الكوماند ]] = {"police.pc", 0, 0, 0}, 
		["eUniform2"] = {"emergency.vehicle", 0, 0, 0},
		["eUniform3"] = {"police.pc2", 0, 0, 0},
	},
	
	Permissions = { -- البرمشنات
		-- يمديك تضيف برمشن او رتبة
		
		-- ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ البرمشنات الي تحتاج تعديل ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓

		Police =       "police.vehicle", -- برمشن يشمل جميع قطاع الداخلية او الشرطة
		EMS =          "emergency.vehicle", -- برمشن يشمل جميع قطاع الصحة

		TpAll =        "police.tpall", -- سحب جميع الاداريين
		RankUp =       "police.rankup", -- -- ترقية
		RankDown =     "police.rankdown", -- تنزيل
		ShowRank =     "police.rankshow", -- اظهار الرتبة
		Uniform =      "police.vehicle", -- الزي الرسم (اعادة تعيين البريهة)
		Loadout =      "poliffce.vehicle", -- العتاد
		Message =      "police.message", -- رسالة لجميع العساكر
		AddJob =       "police.addjob", -- توظيف الشرطة
		Shield =       "police.putinveh", -- تعبئة الدرع [NEW]
		RemoveJob =    "police.removejob", -- فصل الشرطة
		EmsMessage =   "ems.message", -- رسالة لجميع المسعفين
		EmsAddJob =    "ems.addjob", -- توظيف المسعفين
		EmsRemoveJob = "ems.removejob", -- فصل المسعفين
		EmsTpAll =     "ems.tpall",

		-- ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑ البرمشنات الي تحتاج تعديل ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑
		
		Check =        "police.check", -- تفتيش
		Cuff =         "police.easy_cuff", -- كلبشة
		Drag =         "police.easy_cuff", -- حمل
		Fine =         "police.fine", -- مخالفة
		Jail =         "police.jail", -- سجن
		Menu =         "police.menu", -- قائمة الشرطة
		InVeh =        "police.putinveh", -- اجبار دخول
		OutVeh =       "police.getoutveh", -- اجبار خروج

		Revive =       "emergency.revive", -- انعاش لاعب
		Heal =         "emergency.revive", -- معالجة لاعب
		ReviveMe =     "emergency.revive" -- انعاش نفسك (لازم بيلز)
		
	},

	Logs = { -- اللوقات
		TpAll =        "", -- سحب جميع الاداريين
		RankUp =       "", -- -- ترقية
		RankDown =     "", -- تنزيل
		ShowRank =     "", -- اظهار الرتبة
		Uniform =      "", -- الزي الرسم (اعادة تعيين البريهة)
		Loadout =      "", -- العتاد
		Message =      "", -- رسالة لجميع العساكر
		AddJob =       "", -- توظيف الشرطة
		RemoveJob =    "", -- فصل الشرطة

		EmsMessage =   "", -- رسالة لجميع المسعفين
		EmsAddJob =    "", -- توظيف المسعفين
		EmsRemoveJob = "", -- فصل المسعفين
		EmsTpAll =     "",
		Check =        "", -- تفتيش
		Cuff =         "", -- كلبشة
		Drag =         "", -- حمل
		Fine =         "", -- مخالفة
		Jail =         "", -- سجن
		InVeh =        "", -- اجبار دخول
		OutVeh =       "", -- اجبار خروج
		Shield =       "", -- تعبئة درع [NEW]
		Revive =       "", -- انعاش لاعب
		Heal =         "", -- معالجة لاعب
		ReviveMe =     "" -- انعاش نفسك (لازم بيلز)
	},
	
	-- >>>>>>>>>>>>>>>>>>>>>>>>>>>> للمبرمجين فقط <<<<<<<<<<<<<<<<<<<<<<<<<<<<

	-- >>>>>>>>>>>>>>>>>>> لا تعدل اذا كنت مو عارف وش قاعد تسوي <<<<<<<<<<<<<<<<<<<
	OuterLabels = { "imgsrc:Q05959p.png", "imgsrc:S9rhMxz.png", "imgsrc:aQ67PiK.png", "imgsrc:2j3GheW.png", "imgsrc:KbgGPOg.png", "imgsrc:Fanc4yV.png", "imgsrc:UNIunyd.png", "imgsrc:MpkWpX9.png", "imgsrc:oR17BTd.png", "imgsrc:wh4V583.png", "imgsrc:df0beRt.png", "imgsrc:cNmIHjY.png", "imgsrc:GiF0Xgh.png", "imgsrc:VqrQayQ.png" },
	OuterCommands = { Menu.Close, "epCheckPlayer", "epToggleCuff", "epToggleDrag", "epFinePlayer", "epJailPlayer", "epPoliceMenu", "epInVehicle", "epOutVehicle", "epRank-Menu", "epShowRank", "epUniform-Menu", "epLoadout", "epShield"},
	
	InnerLabels = { "imgsrc:0bs1IdW.png", "imgsrc:c4GjOXm.png", "imgsrc:NFJA2xy.png" },
	InnerCommands = { "epRevive-Menu", "epPoliceManagment-Menu", "epEmsManagment-Menu" },
	
	SubMenus = {
		["epUniform-Menu"] = {
			labels = { 'قطاع 1', 'قطاع 2', 'قطاع 3' }, 
			commands = { 'eUniform', 'eUniform2', 'eUniform3' }
		},
		["epRevive-Menu"] = {
			labels = { 'imgsrc:P0QezGD.png', 'imgsrc:ularZHP.png', 'imgsrc:eenHYtm.png' }, 
			commands = { 'epSelfRevive', 'epPlayerRevive', 'epPlayerHeal' }
		},
		["epRank-Menu"] = {
			labels = { 'imgsrc:7GZ1oCr.png', 'imgsrc:UYc54Ez.png', }, 
			commands = { 'epRankUp', 'epRankDown' }
		},
		["epPoliceManagment-Menu"] = {
			labels = { 'imgsrc:5h3fgJq.png', 'imgsrc:s0FdmdF.png', 'imgsrc:4iQBIJD.png', 'imgsrc:WxallBH.png' }, 
			commands = { 'epPoliceMessage', 'epGiveJob', 'epPoliceTp', 'epRemoveJob' }
		},
		["epEmsManagment-Menu"] = {
			labels = { 'imgsrc:TA89jij.png', 'imgsrc:s0FdmdF.png', 'imgsrc:6XZMpD0.png', 'imgsrc:WxallBH.png' }, 
			commands = { 'epُEmsMessage', 'epEmsGiveJob', 'epEMSTp', 'epEmsRemoveJob' }
		},
	}
}
--[[
	███████╗ █████╗ ███████╗██╗   ██╗██████╗ 
	██╔════╝██╔══██╗██╔════╝╚██╗ ██╔╝╚════██╗
	█████╗  ███████║███████╗ ╚████╔╝   ▄███╔╝
	██╔══╝  ██╔══██║╚════██║  ╚██╔╝    ▀▀══╝ 
	███████╗██║  ██║███████║   ██║     ██╗   
	╚══════╝╚═╝  ╚═╝╚══════╝   ╚═╝     ╚═╝
	=========================================
	
	Made By : Easy?#1111
    Discord : https://easy.community/request/redirect?l=discord
	
	♥ شكرا لثقتك بنا ♥
]]		
