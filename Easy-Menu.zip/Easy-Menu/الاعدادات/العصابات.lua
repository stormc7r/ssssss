--[[
	███████╗ █████╗ ███████╗██╗   ██╗██████╗ 
	██╔════╝██╔══██╗██╔════╝╚██╗ ██╔╝╚════██╗
	█████╗  ███████║███████╗ ╚████╔╝   ▄███╔╝
	██╔══╝  ██╔══██║╚════██║  ╚██╔╝    ▀▀══╝ 
	███████╗██║  ██║███████║   ██║     ██╗   
	╚══════╝╚═╝  ╚═╝╚══════╝   ╚═╝     ╚═╝
	=========================================
	
	Made By : Easy?#1111
    Discord : https://easy.community/request/redirect?l=discord
	
	♥ شكرا لثقتك بنا ♥
]]
Menu.Gang = {

	Loadout = { -- عتاد الشرطة
		Timer = 10, -- المدة بالدقائق للانتي سبام
		
		Shield = true, -- هل تبي يجي درع للاعب وقت يستلم العتاد؟
		
		Weapons = {
			["WEAPON_PISTOL"] = {ammo=999},
			["WEAPON_ASSAULTRIFLE"] = {ammo=999},
			["WEAPON_HEAVYSHOTGUN"] = {ammo=999},
		}
	},
	
	StoreWTimer = 3, -- المدة بالدقائق لكل مرة يقدر اللاعب فيها يخزن الاسلحة
	
	LootTimer = 5, -- المدة بالدقائق لكل مرة يقدر اللاعب يعمل لوت للاعبين
	
	OnLoot = { -- اغراض رح يستلمها اللاعب بشكل تلقائي وقت يلوت شخص
		{name = "قلب", amount = 1},
		{name = "يد", amount = 2},
		{name = "راس", amount = 1}
	},
	
	Permissions = { -- البرمشنات
		-- يمديك تضيف برمشن او رتبة

		Gangs =		 "all.gangs", -- برمشن يشمل جميع العصابات يستخدم لسحب جميع العصابات

		Cuff =	     "police.easy_cuff", -- برمشن كلبشة لاعب
		Drag =	     "police.drag", -- سحب لاعب
		Check =	     "police.check", -- تفتيش لاعب
		InVeh =      "police.putinveh", -- اجبار دخول
		OutVeh =     "police.getoutveh", -- اجبار خروج
		UnStoreWe =  "player.phone", -- فك تخزين الاسلحة
		StoreWe =    "player.phone", -- تخزين الاسلحة
		TpAll =      "gang.tpall", -- سحب الكل
		Message =    "gang.message", -- ارسال رسالة
		Loadout =    "gang.loadout", -- العتاد
		Loot =	     "player.phone", -- تلويت لاعب
		Headbag =    "police.headbag", -- تغطية الوجه
	},

	Logs = { -- اللوقات
		Cuff =	     "", -- برمشن كلبشة لاعب
		Drag =	     "", -- سحب لاعب
		Check =	     "", -- تفتيش لاعب
		InVeh =      "", -- اجبار دخول
		OutVeh =     "", -- اجبار خروج
		UnStoreWe =  "", -- فك تخزين الاسلحة
		StoreWe =    "", -- تخزين الاسلحة
		TpAll =      "", -- سحب الكل
		Message =    "", -- ارسال رسالة
		Loadout =    "", -- العتاد
		Loot =	     "", -- تلويت لاعب
		Headbag =    "" -- تغطية الوجه
	},
	
	-- >>>>>>>>>>>>>>>>>>>>>>>>>>>> للمبرمجين فقط <<<<<<<<<<<<<<<<<<<<<<<<<<<<

	-- >>>>>>>>>>>>>>>>>>> لا تعدل اذا كنت مو عارف وش قاعد تسوي <<<<<<<<<<<<<<<<<<<
	OuterLabels = { "imgsrc:Q05959p.png", "imgsrc:ECoY4xf.png", "imgsrc:Tz7uPgD.png", "imgsrc:m9XzaVW.png", "imgsrc:84zkwkb.png", "imgsrc:zP7GU7E.png", "imgsrc:mq5pnLP.png", "imgsrc:0aD0kPl.png",
    "imgsrc:Z6alyLX.png" },
	OuterCommands = { Menu.Close, "egToggleCuff", "egToggleDrag", "egCheckPlayer", "egInVehicle", "egOutVehicle", "egUnstoreWe", "egStoreWe", "egGang-Menu" },

	InnerLabels = { "imgsrc:GiF0Xgh.png", "imgsrc:sEJO89A.png", "imgsrc:vm2YVCY.png", "imgsrc:RsT9tK2.png" },
	InnerCommands = { "egLoadout", "egLoot", "takehostage", "egHeadbag" },

	SubMenus = {
		["egGang-Menu"] = { -- لازم تضيف -Menu لكل وحدة تبي تضيفها
			labels = { "imgsrc:Y67LNsQ.png", "imgsrc:S8QoFvP.png" }, 
			commands = { "egGangTp", "egGangMessage" }
		}
	}
	
}
--[[
	███████╗ █████╗ ███████╗██╗   ██╗██████╗ 
	██╔════╝██╔══██╗██╔════╝╚██╗ ██╔╝╚════██╗
	█████╗  ███████║███████╗ ╚████╔╝   ▄███╔╝
	██╔══╝  ██╔══██║╚════██║  ╚██╔╝    ▀▀══╝ 
	███████╗██║  ██║███████║   ██║     ██╗   
	╚══════╝╚═╝  ╚═╝╚══════╝   ╚═╝     ╚═╝
	=========================================
	
	Made By : Easy?#1111
    Discord : https://easy.community/request/redirect?l=discord
	
	♥ شكرا لثقتك بنا ♥
]]