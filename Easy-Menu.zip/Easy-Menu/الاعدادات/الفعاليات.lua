--[[
	███████╗ █████╗ ███████╗██╗   ██╗██████╗ 
	██╔════╝██╔══██╗██╔════╝╚██╗ ██╔╝╚════██╗
	█████╗  ███████║███████╗ ╚████╔╝   ▄███╔╝
	██╔══╝  ██╔══██║╚════██║  ╚██╔╝    ▀▀══╝ 
	███████╗██║  ██║███████║   ██║     ██╗   
	╚══════╝╚═╝  ╚═╝╚══════╝   ╚═╝     ╚═╝
	=========================================
	
	Made By : Easy?#1111
    Discord : https://easy.community/request/redirect?l=discord
	
	♥ شكرا لثقتك بنا ♥
]]
Menu.Event = {
	
	Loadout = {
		['WEAPON_ASSAULTRIFLE'] = {ammo = 200},
		['WEAPON_APPISTOL'] = {ammo = 200}
	},
	
	MaxRange = 150, -- الحد الاقصى لبعد المحيط
	
	Zones = {
		Safe = {
			Marker = 1, -->> شكل الماركر
			Color = {255, 0, 0, 150}, -->> [ RGBA ] لون الماركر
			Top = 0.2, -->> ارتفاع الماركر
			UpOnDown = true, -->> الماركر يصعد فوق وتحت
			Spins = true, -->> يدور حول نفسه
		},
		Speed = {
			Marker = 1, -->> شكل الماركر
			Color = {255, 0, 0, 150}, -->> [ RGBA ] لون الماركر
			Top = 0.2, -->> ارتفاع الماركر
			UpOnDown = true, -->> الماركر يصعد فوق وتحت
			Spins = true, -->> يدور حول نفسه
		},
	},
	
	Permissions = { -- البرمشنات
		-- يمديك تضيف برمشن او رتبة
		
		Freeze  	= 	"admin.tickets", -- تجميد الحركة
		Zone 		= 	"admin.tickets", -- الدوائر
		Loadout 	= 	"admin.tickets", -- اعطاء عتاد
		Message 	= 	"admin.tickets", -- ارسال رسالة
		Money   	= 	"admin.tickets", -- اعطاء نقود
		Shield  	= 	"admin.tickets", -- اعطاء درع
		Teleport  	= 	"admin.tickets", -- نقل اللاعبين
		Heal  		= 	"admin.tickets", -- اعطاء هيل
		FoodDrink  	= 	"admin.tickets", -- اعطاء اكل وشرب
		Timer  		= 	"admin.tickets", -- بدء العد
		ClearVeh	= 	"admin.tickets", -- حذف جميع المركبات
	},
	
	Logs = { -- اللوقات
		Freeze  	= 	"", -- تجميد الحركة
		Zone 		= 	"", -- الدوائر
		Loadout 	= 	"", -- اعطاء عتاد
		Message 	= 	"", -- ارسال رسالة
		Money   	= 	"", -- اعطاء نقود
		Shield  	= 	"", -- اعطاء درع
		Teleport  	= 	"", -- نقل اللاعبين
		Heal  		= 	"", -- اعطاء هيل
		FoodDrink  	= 	"", -- اعطاء اكل وشرب
		Timer  		= 	"", -- بدء العد
		ClearVeh	= 	"", -- حذف جميع المركبات
	},

	-- >>>>>>>>>>>>>>>>>>>>>>>>>>>> للمبرمجين فقط <<<<<<<<<<<<<<<<<<<<<<<<<<<<

	-- >>>>>>>>>>>>>>>>>>> لا تعدل اذا كنت مو عارف وش قاعد تسوي <<<<<<<<<<<<<<<<<<<
	OuterLabels = { "imgsrc:Q05959p.png", "imgsrc:McCN9NA.png", "imgsrc:7ZgVMth.png", "imgsrc:Bj6wm9z.png", "imgsrc:gGVvzN1.png", "imgsrc:uIzzN41.png", "imgsrc:LVQDhWY.png", "imgsrc:5rnZoay.png", "imgsrc:0G5Zjf0.png", "imgsrc:fnj8Rsk.png" },
	OuterCommands = { Menu.Close, "eeZone-Menu", "eeFreeze-Menu", "eeLoadout-Menu", "eeMessage-Menu", "eeMoney-Menu", "eeShield-Menu", "eeTeleport-Menu", "eeHeal-Menu", "eeFoodDrink-Menu" },
	
	InnerLabels = {"imgsrc:fS4BIDW.png", "imgsrc:OEfFYan.png"},
	InnerCommands = { "eeSetTimer", "eeClearVeh" },
	
	SubMenus = {
		["eeFreeze-Menu"] = {
			labels = { "imgsrc:Xiur1pJ.png", "imgsrc:tEUIv1Z.png", "imgsrc:kitXPPY.png", "imgsrc:sHjFjP9.png" }, 
			commands = { "eeFreeze1", "eeFreeze3", "eeFreeze2", "eeFreeze4" }
		},
		["eeZone-Menu"] = {
			labels = { "imgsrc:oY0NzsD.png", "imgsrc:CM3oa4c.png" }, 
			commands = { "eeZone1", "eeZone2" }
		},
		["eeLoadout-Menu"] = {
			labels = { "imgsrc:Xiur1pJ.png", "imgsrc:kitXPPY.png", "imgsrc:yyc9e3L.png" }, 
			commands = { "eeLoadout1", "eeLoadout2", "eeLoadout3" }
		},
		["eeMessage-Menu"] = {
			labels = { "imgsrc:Xiur1pJ.png", "imgsrc:kitXPPY.png", "imgsrc:yyc9e3L.png" }, 
			commands = { "eeMessage1", "eeMessage2", "eeMessage3" }
		},
		["eeMoney-Menu"] = {
			labels = { "imgsrc:Xiur1pJ.png", "imgsrc:kitXPPY.png", "imgsrc:yyc9e3L.png" }, 
			commands = { "eeMoney1", "eeMoney2", "eeMoney3" }
		},
		["eeShield-Menu"] = {
			labels = { "imgsrc:Xiur1pJ.png", "imgsrc:kitXPPY.png", "imgsrc:yyc9e3L.png" }, 
			commands = { "eeShield1", "eeShield2", "eeShield3" }
		},
		["eeTeleport-Menu"] = {
			labels = { "imgsrc:glgS7sc.png", "imgsrc:XEuJh1v.png" }, 
			commands = { "eeTeleport1", "eeTeleport2" }
		},
		["eeHeal-Menu"] = {
			labels = { "imgsrc:Xiur1pJ.png", "imgsrc:kitXPPY.png", "imgsrc:yyc9e3L.png" }, 
			commands = { "eeHeal1", "eeHeal2", "eeHeal3" }
		},
		["eeFoodDrink-Menu"] = {
			labels = { "imgsrc:Xiur1pJ.png", "imgsrc:kitXPPY.png", "imgsrc:yyc9e3L.png" }, 
			commands = { "eeFoodDrink1", "eeFoodDrink2", "eeFoodDrink3" }
		},
	}
}
--[[
	███████╗ █████╗ ███████╗██╗   ██╗██████╗ 
	██╔════╝██╔══██╗██╔════╝╚██╗ ██╔╝╚════██╗
	█████╗  ███████║███████╗ ╚████╔╝   ▄███╔╝
	██╔══╝  ██╔══██║╚════██║  ╚██╔╝    ▀▀══╝ 
	███████╗██║  ██║███████║   ██║     ██╗   
	╚══════╝╚═╝  ╚═╝╚══════╝   ╚═╝     ╚═╝
	=========================================
	
	Made By : Easy?#1111
    Discord : https://easy.community/request/redirect?l=discord
	
	♥ شكرا لثقتك بنا ♥
]]