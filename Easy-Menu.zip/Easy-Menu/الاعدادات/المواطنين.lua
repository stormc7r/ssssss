--[[
	███████╗ █████╗ ███████╗██╗   ██╗██████╗ 
	██╔════╝██╔══██╗██╔════╝╚██╗ ██╔╝╚════██╗
	█████╗  ███████║███████╗ ╚████╔╝   ▄███╔╝
	██╔══╝  ██╔══██║╚════██║  ╚██╔╝    ▀▀══╝ 
	███████╗██║  ██║███████║   ██║     ██╗   
	╚══════╝╚═╝  ╚═╝╚══════╝   ╚═╝     ╚═╝
	=========================================
	
	Made By : Easy?#1111
    Discord : https://easy.community/request/redirect?l=discord
	
	♥ شكرا لثقتك بنا ♥
]]
Menu.Citizen = {

	VehRent = { -- استئجار مركبة
		Price = 5000, -- المبلغ الي ينسحب من اللاعب وقت يستئجر مركبة
		Timer = 5, -- المدة بالدقائق لكم مرة اللاعب يقدر فيها يستئجر مركبة
		
		Spawn = { -- هنا يمديك تضيف اكثر من دراجة او مركبة و المنيو رح تختار شي عشوائي
			"bmx",
			"tribike",
			"fixter",
		}
	},
	
	Maps = { -- الاماكن المهمة
		{180.78 --[[ x ]], -1014.94 --[[ y ]]}, -- الحديقة الملكية
		{-626.09, -167.76}, -- الريسبون
		{1813.55, 3260.01}, -- المهجورة
		{0,0}, -- مركز الوظائف
		{408, -980}, -- مركز الشرطة
		{311, -1372}, -- المستشفى
	},
	
	ShareLocPrice = 500, -- المبلغ الي يحتاجه اللاعب عشان يشارك الموقع
	
	EmptyInv = 500, -- المبلغ الي يحتاجه اللاعب لافراغ الحقيبة
	
	Message = 500, -- المبلغ الي ينسحب من اللاعب وقت يرسل رسالة
	
	Logs = { -- اللوقات
		Transfer =	"", -- تحويل نقود
		RentVeh  =	"", -- استئجار مركبة
		Location =	"", -- ارسال الموقع
		Message =	"", -- ارسال رسالة
		EmptyInv =	"" -- افراغ الحقيبة
	},
	
	-- >>>>>>>>>>>>>>>>>>>>>>>>>>>> للمبرمجين فقط <<<<<<<<<<<<<<<<<<<<<<<<<<<<

	-- >>>>>>>>>>>>>>>>>>> لا تعدل اذا كنت مو عارف وش قاعد تسوي <<<<<<<<<<<<<<<<<<<
	
	OuterLabels = { "imgsrc:Q05959p.png", "imgsrc:W438tVD.png", "imgsrc:UuDTpwe.png", "imgsrc:mGGzylr.png", "imgsrc:HnKF4Ti.png", "imgsrc:7uEvHrF.png", "imgsrc:tfWo8nV.png", "imgsrc:tf7dRrZ.png", "imgsrc:U8jA2w3.png", "imgsrc:mzK2anR.png" },
	OuterCommands = { "close", "ecBankTransfer", "ecRentVeh", "dv", "carry", "Maps-Menu", "ecShareLocation", "ecEmptyInv", "ecInventory", "RockstarEditor-Menu" },

	InnerLabels = {"imgsrc:HvfjrBM.png", "imgsrc:ge4bBKz.png", "imgsrc:gGVvzN1.png"},
	InnerCommands = { "ecLeaveServer", "ecJoinDiscord", "ecMessage" },
	
	SubMenus = {
		["RockstarEditor-Menu"] = { -- لازم تضيف -Menu لكل وحدة تبي تضيفها
			labels = { "imgsrc:VVRgHgH.png", "imgsrc:qTWg0p2.png", "imgsrc:21WWM4a.png", "imgsrc:pPVHK4y.png" },
			commands = { "ecStartRecord", "ecStopRecord", "ecSaveRecord", "ecOpenEditor" }
		},
		["Maps-Menu"] = {
			labels = { "الحديقة الملكية", "الريسبون", "المهجورة", "مركز الوظائف", "مركز الشرطة", "المستشفى" },
			commands = { "ecCopyLocation-1", "ecCopyLocation-2", "ecCopyLocation-3", "ecCopyLocation-4", "ecCopyLocation-5", "ecCopyLocation-6" }
		}
	}
}
--[[
	███████╗ █████╗ ███████╗██╗   ██╗██████╗ 
	██╔════╝██╔══██╗██╔════╝╚██╗ ██╔╝╚════██╗
	█████╗  ███████║███████╗ ╚████╔╝   ▄███╔╝
	██╔══╝  ██╔══██║╚════██║  ╚██╔╝    ▀▀══╝ 
	███████╗██║  ██║███████║   ██║     ██╗   
	╚══════╝╚═╝  ╚═╝╚══════╝   ╚═╝     ╚═╝
	=========================================
	
	Made By : Easy?#1111
    Discord : https://easy.community/request/redirect?l=discord
	
	♥ شكرا لثقتك بنا ♥
]]